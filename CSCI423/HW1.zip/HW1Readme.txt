Files:
	HW1Readme
	HW1parta.c
	HW1partb.c
	input.txt


To run and compile both HW1parta && HW1partb    gcc <filename> <input file> <output file> 

If <output file> does not exist, it will be created. If exist, it will be overwritten.

Part a reads the file, and outputs the file in same order
Part b reads the file of integers and outputs the integers in ascending order. 

Gregory Phillips 
10678899

