Files:
    HW2Readme.txt
    HW2.c
    

To compile HW2.c :: gcc HW2.c

To Run: ./a.out <somePositiveNumber> 

If the argument is negative, error will be thrown and close. 
If more than one argument, error will be thrown and close.

[SAMPLE OUTPUT]
./a.out 8
8, 4, 2, 1,


Gregory Phillips
10678899s

